# CadastraAI REST API Specification (FastAPI on Port 8001)

## Base URL: `http://127.0.0.1:8001`

### 1. System Health
- **`GET /api/health`**: Returns service status and online confirmation.

### 2. Cadastral Extraction & Projects
- **`POST /api/projects/{id}/extract`**: Runs sliding-window deep learning extraction on drone orthomosaics.
- **`GET /api/projects/{id}/parcels`**: Retrieves all cadastral parcels, buildings, and road centerlines with survey metadata.
- **`POST /api/projects/{id}/parcels/{pid}/verify`**: Records surveyor approval and creates an immutable audit trail entry.

### 3. Geometric Topology
- **`POST /api/projects/{id}/topology/validate`**: Executes Shapely validation for overlaps, slivers, and unclosed linear rings.
- **`POST /api/projects/{id}/topology/snap`**: Executes sub-meter vertex snapping across adjacent boundaries using $0.15\text{ m}$ tolerance.

### 4. Ground Truth & GNSS Validation
- **`POST /api/projects/{id}/validate/ground-truth`**: Calculates Spatial IoU and Hausdorff boundary distances against surveyed deeds.
- **`POST /api/projects/{id}/validate/gnss-cors`**: Calculates field RTK benchmark errors and evaluates RMSE compliance against $0.30\text{ m}$.

### 5. Multi-Format GIS Exports
- **`GET /api/projects/{id}/export/geojson`**: RFC 7946 FeatureCollection.
- **`GET /api/projects/{id}/export/shapefile`**: Zipped ESRI Shapefile bundle (`.shp`, `.shx`, `.dbf`, `.prj`).
- **`GET /api/projects/{id}/export/kml`**: Google Earth Placemarks and LinearRings.
- **`GET /api/projects/{id}/export/dxf`**: AutoCAD 2D lightweight polylines.
- **`GET /api/projects/{id}/export/pdf`**: Formal statutory cadastral survey preparation report.
