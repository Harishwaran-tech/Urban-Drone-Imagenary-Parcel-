# Frontend Tech Stack & Architecture

## 1. Core Technologies

| Technology | Version | Purpose |
| :--- | :--- | :--- |
| **Vite** | `^5.4.8` | Lightning-fast HMR and production bundling |
| **React** | `^18.3.1` | Declarative component UI engine |
| **TypeScript** | `^5.5.3` | Strict type safety and cadastral data modeling |
| **Three.js** | `^0.160.0` | 3D WebGL Digital Twin and PBR rendering |
| **Leaflet** | `^1.9.4` | 2D interactive WebGIS vector mapping |
| **Tailwind CSS** | `^3.4.1` | Responsive styling and glassmorphism |
| **Lucide React** | `^0.344.0` | Professional cartographic and GIS iconography |

---

## 2. 3D Procedural Digital Twin Engine (`src/services/gis3d/`)

- **`proceduralBuildingEngine.ts`**: Coordinates building massing, procedural facades, and roof generation.
- **`facadeGenerator.ts`**: Generates window bays, sills, and recessed balconies.
- **`roofGenerator.ts`**: Generates flat roofs with parapets, gable pitched roofs, and hip roofs.
- **`rooftopGenerator.ts`**: Populates rooftop HVAC units, water tanks, and solar panels.
- **`materialSystem.ts`**: Realistic PBR shaders with roughness and metalness maps.
- **`heightEstimator.ts`**: Computes nDSM elevation differentials (`nDSM = DSM - DTM`).
- **`geometryAnalysis.ts`**: Evaluates footprint aspect ratios and principal orientation vectors.
- **`proceduralSeed.ts`**: Deterministic PRNG to ensure procedural features remain consistent across sessions.

---

## 3. Centralized Map Styling System (`src/utils/mapStyles.ts`)

- Defines 7 analytical view presets (`survey`, `ai_review`, `topology`, `ground_truth`, `land_use`, `clean_imagery`, `presentation`).
- Establishes cartographic hierarchy:
  - Existing Cadastre: Solid thin cyan (`#06b6d4`, 1.6px)
  - AI Boundary: Dashed purple (`#8b5cf6`, 1.8px, `dashArray: '5, 5'`)
  - Active Selection: Bold cyan highlight (`#00e5ff`, 3.5px)
- Centralized conflict taxonomy with hex colors, badges, and distinct symbols (`⧉`, `⫿`, `✕`, `↔`, `⌂`).
