# Cadastral Survey Conditions & Geometric Topology Standards

## 1. Survey Accuracy & Tolerance Thresholds

| Metric | Survey Threshold | Enforcement Mechanism |
| :--- | :--- | :--- |
| **Snapping Tolerance** | **$0.15\text{ m}$ ($15\text{ cm}$)** | `backend/services/topology_service.py` via `snap(poly1, poly2, 0.0000015)` |
| **GNSS RTK RMSE** | **$< 0.30\text{ m}$ ($30\text{ cm}$)** | `backend/services/survey_validation_service.py` evaluated against CORS benchmarks |
| **Overlap Area Limit** | **$2.0\text{ m}^2$** | Flagged as critical boundary dispute if $A_{\text{overlap}} > 2.0\text{ m}^2$ |
| **Sliver Polygon Limit**| **$12.0\text{ m}^2$** with compactness $< 0.15$ | Flagged as sliver artifact and cleaned |
| **Displacement Ranks** | `[0-0.15m: Green, 0.15-0.30m: Yellow, 0.30-0.50m: Orange, >0.50m: Red]` | Color-coded boundary displacement heatmap |

---

## 2. Coordinate Reference System (CRS) Standards

- **Primary Storage**: WGS84 Geographic Coordinates (`EPSG:4326`) in decimal degrees with 7 decimal places precision ($~0.011\text{ m}$).
- **Local Metric Computation**: Projected UTM Grid Coordinates (e.g., UTM Zone 43N / 44N, `EPSG:32643` / `EPSG:32644`) for metric distance, perimeter, and area calculations.
- **Drone Imagery Georeferencing**: Aligned using affine transformation matrix parsed from GeoTIFF tags (`ModelTiepointTag`, `ModelPixelScaleTag`) or World files (`.tfw`).
