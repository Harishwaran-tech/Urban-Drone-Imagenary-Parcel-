# Backend Tech Stack & Architectural Services

## 1. Core Technologies

| Technology | Purpose |
| :--- | :--- |
| **FastAPI** | High-performance asynchronous REST API framework (Port 8001) |
| **Python 3.10+** | Modern Python with dataclasses and type hinting |
| **Shapely** | GEOS-backed 2D geometric topology analysis and polygon manipulation |
| **PyProj** | Geodesic transformations (WGS 84 `EPSG:4326` to UTM projected grids) |
| **PyShp (`shapefile`)** | Native generation of ESRI Shapefile packages (`.shp`, `.shx`, `.dbf`, `.prj`) |
| **ReportLab** | PDF generation engine for official survey reports |
| **NumPy & SciPy** | Matrix operations for tiled raster processing and Hann window blending |
| **Uvicorn** | ASGI server running on `http://127.0.0.1:8001` |

---

## 2. Specialized Services

- **`tiled_inference.py`**: 512x512 sliding window with Hann window blending to eliminate edge seam artifacts on large orthomosaics.
- **`topology_service.py`**: Automated geometric topology validation with **$0.15\text{ m}$ snapping tolerance**, overlap detection, sliver filtering, and `make_valid` repairs.
- **`survey_validation_service.py`**: Ground truth spatial IoU and Hausdorff distance calculations; GNSS RTK horizontal error and RMSE evaluation against the $0.30\text{ m}$ statutory tolerance.
- **`elevation_service.py`**: Normalised Digital Surface Model (`nDSM = DSM - DTM`) computation for accurate building structure heights.
- **`export_service.py`**: Multi-format exports into zipped ESRI Shapefiles, GeoJSON, Google Earth KML, AutoCAD DXF, and formal Cadastral Preparation PDFs.
