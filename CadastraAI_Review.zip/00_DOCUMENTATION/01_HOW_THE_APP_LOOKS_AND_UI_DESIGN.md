# How the Application Looks & UI Design System

## 1. Executive Design Overview

CadastraAI delivers a state-of-the-art geospatial engineering platform designed for cadastral surveyors, land administration departments, and GIS analysts. It balances rigorous metric precision with high-performance WebGL/Leaflet rendering:
- **Calibrated Cartographic Palette**: Avoids harsh neon colors. Subtle solid cyan (`#06b6d4`, 1.6px) for existing legal parcels; dashed purple (`#8b5cf6`, 1.8px) for AI-detected boundaries; luminous cyan (`#00e5ff`, 3.5px) for the active selection.
- **Glassmorphic Floating Surfaces**: Translucent navigation toolbars and inspector cards with backdrop blur (`backdrop-blur-md bg-white/95` in light mode, `bg-slate-900/95` in 3D dark mode).
- **Survey-Grade Typography**: Crisp sans-serif fonts paired with tabular monospace numbers for lot IDs, areas ($m^2$), coordinates, and elevations.

---

## 2. 2D Interactive WebGIS Viewport (`/gis`)

### 2.1 Overlay Clutter Reduction & Opacity Hierarchy
- **Normal Unselected Parcels**: Translucent fill opacity set to **`0.07`** (`7%`), allowing underlying high-resolution drone orthomosaic imagery, trees, boundary markers, and building shadows to remain clearly visible.
- **Selected Parcel**: Highlighted with a luminous **`0.22`** fill and an unmistakable **`3.5px`** cyan outline.
- **AI Difference Highlights**: Matched boundaries (green), AI-only preliminary boundaries (dashed purple), existing deed boundaries (amber dashed), and discrepancy areas (red translucent fill).
- **Actual Topology Error Geometry Rendering**:
  - Overlap polygons: distinct cross-hatched red geometry with exact area callout (e.g., `14.8 m²`).
  - Gap slivers: hatched orange boundary strips (e.g., `0.65 m`).
  - Building encroachments: magenta encroachment lines and conflict beacons (e.g., `1.8 m`).
- **Zoom-Dependent Rendering**: Small-scale regional view (`zoom < 16`) hides heavy parcel survey ID labels, building tags, GNSS RTK markers, and vertex handles. At `zoom >= 16`, survey lot badges, dimension markers, corner vertices, and topological issues appear automatically.

### 2.2 Compact Master Toolbar & Status Strip
- **Master Presets Bar**: Scrollable top pill bar offering 7 dedicated view presets:
  1. `Survey Cadastre` (Authoritative existing boundary map)
  2. `AI Boundary Review` (AI predictions vs existing deed difference view)
  3. `Topology Validation` (Overlaps, gaps, and encroachment slivers)
  4. `Ground Truth Benchmark` (Spatial IoU and boundary distance verification)
  5. `Land Use (LULC)` (6-class semantic color map)
  6. `Clean Orthomosaic` (Imagery inspection with hidden overlays)
  7. `Presentation` (Visual portfolio styling)
- **Compact Status Strip**: A single-line status bar at the bottom:
  `12,486 Parcels • 8,932 Buildings • 126 Issues • AI 94% • IoU 89.6%`
  with an expandable drawer toggle (`Expand Details` / `Hide Details`) that recovers ~70px of vertical map space.
- **Collapsible Workspace Drawers**: Both the Left Project Drawer (`w-72`) and Right Cadastral Inspector Drawer (`w-80`) collapse to `w-0` with one click, providing **100% full-screen map coverage**. A `ResizeObserver` automatically invalidates the Leaflet map size upon drawer transitions.

---

## 3. 3D Cadastral Digital Twin Viewport

### 3.1 Three Distinct 3D Operational Modes
1. **Survey Mode**:
   - Precise geometric massing based on measured nDSM heights.
   - Neutral architectural materials (matte limestone, honed concrete) with zero decorative distractions.
   - Decorative vegetation suppressed to guarantee unobstructed cadastral sightlines.
   - **Vertical Projection Curtain**: Semi-transparent luminous cyan ribbons extruded vertically to define legal 3D cadastral parcel volumes.
2. **Analysis Mode**:
   - Thematic semantic coloring (by Status, Land Use, Height Ramp, Confidence, or Conflict).
   - Volumetric 3D conflict beacons and building encroachment volumes extruded in vivid red.
   - Real-time DTM terrain color ramps (`elevation`, `hillshade`, `slope`, `ndsm`).
3. **Presentation Mode**:
   - High-realism procedural architecture: commercial curtain-wall glass, residential recessed balconies, industrial corrugated sheds.
   - Plausible roof styles (flat parapets, gable pitch, hip roofs, rooftop HVAC, water tanks, solar panels).
   - High-performance instanced 3D tree meshes (`InstancedMesh`) and dynamic time-of-day sunlight/shadow simulations (7:00 AM to 8:00 PM).
   - Optional auto-orbit presentation tour mode (strictly disabled in Survey & Analysis modes).

### 3.2 Realistic Procedural Aerial Orthomosaic Ground Texture
- Ground plane is textured with a procedural high-resolution aerial orthomosaic texture with plot lines, soil textures, and road markings, guaranteeing the 3D ground is never flat white or blank even before a custom drone image is uploaded.
- Draped dark asphalt roads (`#1e293b`) with yellow centerlines follow the DTM terrain elevation smoothly.

### 3.3 Compact 3D Building Inspection Card
- Located at `bottom-12 left-4 z-40` with `stopPropagation` to prevent accidental raycast re-selection.
- **Header**: Building ID, Lot #{surveyNumber}, Status badge, and dismiss button (`X`).
- **Essential Metrics (Compact View)**:
  - Height with **Attribute Provenance Badges**: `[Measured]` (DSM/DTM LiDAR), `[Estimated]` (shadow/stereo AI), `[Inferred]` (zoning rules).
  - Footprint area ($m^2$).
  - Floors with provenance badge.
  - Confidence percentage.
  - Active conflict alert strip if an issue exists (e.g. `Encroachment: 1.8 m`).
- **Expand Toggle**: "Show Detailed Attributes" reveals structure type, elevation ASL, roof style with provenance badge, legal owner, and quick camera action buttons (`Facade Close-Up` and `Overview`).

### 3.4 Camera Navigation Presets
- `Fit Project`: Fits camera extents to the entire cadastral survey project.
- `Fit Selection`: Centers and frames the selected parcel and its 3D building.
- `North Up`: Orients camera to strict 0° azimuth survey orientation.
- `Oblique`: 3D architectural perspective.
- `Iso`: Isometric 3D angle.
- `Top Down`: Orthographic nadir view.

---

## 4. Platform Pages Overview

1. **Dashboard (`/`)**: High-level cadastral intelligence with KPI counters (Total Parcels, Total Buildings, Conflicts, Accuracy), Model Performance metrics, and quick action shortcuts.
2. **WebGIS (`/gis`)**: Unified survey workspace combining 2D Leaflet vector map and 3D Three.js Digital Twin.
3. **Field Verification (`/verify`)**: Field GNSS/CORS RTK ground control benchmark validation with horizontal error calculations and RMSE compliance indicators.
4. **Conflict Analysis (`/conflicts`)**: Discrepancy polygon inspector showing deed vs. AI boundary shifts, encroachment square meters, and resolution workflows.
5. **Topology Validation (`/topology`)**: Automated geometric topology checks identifying overlaps, slivers, self-intersections, and automated 0.15m snapping repairs.
6. **Survey Reports (`/reports`)**: Official survey preparation reporting dashboard with multi-format export buttons (ESRI Shapefile ZIP, GeoJSON, KML, DXF, Official PDF Report).
